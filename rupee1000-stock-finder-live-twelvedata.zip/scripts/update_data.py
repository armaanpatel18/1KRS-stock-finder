"""
Refresh data/stocks.json from Twelve Data.

Provider:
  Twelve Data — https://twelvedata.com/

Why Twelve Data:
  - It lists NSE (XNSE) and BSE (XBOM) coverage.
  - It exposes price/time-series and a statistics endpoint with valuation,
    cash-flow and financial metrics.
  - The statistics endpoint is a paid endpoint; this script therefore fails
    safely if the required plan/key is not available.

Environment:
  TWELVE_DATA_API_KEY  (required)
  TD_SYMBOLS            (optional comma-separated NSE symbols)

Important:
  This script NEVER invents missing values. If required data is missing or
  the provider returns an error, the old stocks.json is preserved and the
  workflow fails. That prevents stale/demo/synthetic data from being silently
  published as live data.
"""

from __future__ import annotations

import json
import math
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen

BASE = "https://api.twelvedata.com"
ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
OUT = DATA / "stocks.json"
UNIVERSE = DATA / "universe.json"

API_KEY = os.getenv("TWELVE_DATA_API_KEY")
if not API_KEY:
    raise SystemExit("Missing TWELVE_DATA_API_KEY GitHub Actions secret.")

symbols_env = os.getenv("TD_SYMBOLS", "").strip()
if symbols_env:
    symbols = [s.strip().upper() for s in symbols_env.split(",") if s.strip()]
else:
    symbols = json.loads(UNIVERSE.read_text())["symbols"]

if not symbols:
    raise SystemExit("No NSE symbols configured.")

def request_json(endpoint: str, symbol: str) -> dict:
    query = urlencode({"symbol": f"{symbol}:NSE", "apikey": API_KEY})
    req = Request(
        f"{BASE}/{endpoint}?{query}",
        headers={"User-Agent": "rupee1000-stock-finder/1.0"},
    )
    with urlopen(req, timeout=30) as r:
        payload = json.loads(r.read().decode("utf-8"))

    if payload.get("status") == "error" or payload.get("code"):
        raise RuntimeError(
            f"{endpoint} failed for {symbol}: {payload.get('message', payload)}"
        )
    return payload

def num(value):
    if value is None or value == "":
        return None
    try:
        x = float(value)
        return x if math.isfinite(x) else None
    except (TypeError, ValueError):
        return None

def first(d, *keys):
    for k in keys:
        if isinstance(d, dict) and k in d and d[k] is not None:
            return d[k]
    return None

def score_stock(s):
    # Conservative score. Missing inputs receive no points, never guessed points.
    score = 0
    coverage = 0

    def add(condition, weight, available=True):
        nonlocal score, coverage
        if available:
            coverage += weight
            if condition:
                score += weight

    roce = s["roce"]
    roe = s["roe"]
    pe = s["pe"]
    peg = s["peg"]
    de = s["de"]
    ocf = s["operatingCashFlow"]
    fcf = s["freeCashFlow"]
    margin = s["profitMargin"]

    add(roce is not None and roce >= 15, 15, roce is not None)
    add(roe is not None and roe >= 15, 15, roe is not None)
    add(de is not None and de <= 0.5, 15, de is not None)
    add(ocf is not None and ocf > 0, 10, ocf is not None)
    add(fcf is not None and fcf > 0, 10, fcf is not None)
    add(pe is not None and 0 < pe <= 25, 15, pe is not None)
    add(peg is not None and 0 < peg <= 1.5, 10, peg is not None)
    add(margin is not None and margin > 0, 10, margin is not None)

    # Normalize to 100 only when at least 70% of the score inputs exist.
    if coverage < 70:
        return None, coverage
    return round(score / coverage * 100), coverage

def tag(stock):
    score = stock["score"]
    upside = stock["upside"]
    pe = stock["pe"]
    if score is not None and score >= 75 and upside is not None and upside >= 15:
        return "undervalued"
    if score is not None and score >= 75:
        return "growth"
    if score is not None and score >= 55:
        return "watch"
    return "trap"

# Fair value is intentionally NOT fabricated. This implementation uses a
# transparent earnings-multiple model only when EPS and a current P/E exist.
# It is a screening estimate, not intrinsic value.
TARGET_PE = 20.0

previous = None
if OUT.exists():
    try:
        previous = json.loads(OUT.read_text())
    except Exception:
        previous = None

results = []
errors = []

for symbol in symbols:
    try:
        # Price endpoint is cheap; statistics contains the fundamental snapshot.
        price_data = request_json("price", symbol)
        stats_data = request_json("statistics", symbol)

        price = num(price_data.get("price"))
        meta = stats_data.get("meta", {})
        stats = stats_data.get("statistics", {})
        val = stats.get("valuations_metrics", {})
        fin = stats.get("financials", {})
        cf = stats.get("cash_flow", {})
        ss = stats.get("stock_statistics", {})

        if price is None:
            raise RuntimeError("Provider returned no price.")

        trailing_pe = num(val.get("trailing_pe"))
        eps = (price / trailing_pe) if trailing_pe and trailing_pe > 0 else None

        # Use only provider-returned values. No missing-value substitution.
        stock = {
            "symbol": symbol,
            "name": meta.get("name"),
            "price": price,
            "fairValue": round(eps * TARGET_PE, 2) if eps is not None else None,
            "pe": trailing_pe,
            "peg": num(val.get("peg_ratio")),
            "pb": num(val.get("price_to_book_mrq")),
            "roce": None,  # Twelve Data statistics does not expose ROCE in the documented snapshot.
            "roe": (num(fin.get("return_on_equity_ttm")) or 0) * 100 if fin.get("return_on_equity_ttm") is not None else None,
            "de": None,    # Not silently inferred: add a balance-sheet provider/endpoint if desired.
            "profitMargin": (num(fin.get("profit_margin")) or 0) * 100 if fin.get("profit_margin") is not None else None,
            "operatingCashFlow": num(cf.get("operating_cash_flow_ttm")),
            "freeCashFlow": num(cf.get("levered_free_cash_flow_ttm")),
            "marketCapCr": (num(val.get("market_capitalization")) / 1e7) if val.get("market_capitalization") is not None else None,
            "insiderPct": num(ss.get("percent_held_by_insiders")),
            "growth5": None,
            "score": None,
            "coverage": 0,
            "tag": "watch",
            "why": "Provider data only. No synthetic values; metrics not supplied by the provider are left blank.",
            "source": "Twelve Data",
            "exchange": meta.get("exchange"),
            "mic_code": meta.get("mic_code"),
        }

        stock["score"], stock["coverage"] = score_stock(stock)
        if stock["fairValue"] is not None:
            stock["upside"] = round((stock["fairValue"] / price - 1) * 100, 2)
        else:
            stock["upside"] = None
        stock["tag"] = tag(stock)

        # Require identity and price; don't publish malformed records.
        if not stock["name"] or stock["price"] <= 0:
            raise RuntimeError("Malformed provider response.")
        results.append(stock)

        # Gentle pacing; adjust to your Twelve Data plan.
        time.sleep(0.5)

    except Exception as exc:
        errors.append(f"{symbol}: {exc}")

if errors:
    # Do not partially overwrite the live dataset. A failed refresh is safer
    # than silently publishing an incomplete universe.
    print("REFRESH FAILED:")
    for e in errors:
        print(" -", e)
    raise SystemExit(1)

if not results:
    raise SystemExit("No valid records returned.")

payload = {
    "updated_at": datetime.now(timezone.utc).isoformat(),
    "currency": "INR",
    "provider": {
        "name": "Twelve Data",
        "exchange": "NSE",
        "mic_code": "XNSE",
        "endpoint": "price + statistics",
        "note": "All populated fields come from the provider or transparent calculations from provider data. Missing metrics are null."
    },
    "stocks": sorted(results, key=lambda x: (x["score"] is None, -(x["score"] or -1)))
}

tmp = OUT.with_suffix(".json.tmp")
tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
tmp.replace(OUT)

print(f"Published {len(results)} verified provider records to {OUT}.")
